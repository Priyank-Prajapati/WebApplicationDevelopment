﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Priyank_P_301112923.Models
{
    public class ViewModel
    {
        public IEnumerable<Club> Clubs { get; set; }
    }
}
