﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations.Schema;

namespace Priyank_P_301112923.Models.Users
{
    // Add profile data for application users by adding properties to the AppUser class
    public class AppUser : IdentityUser
    {

    }
}
